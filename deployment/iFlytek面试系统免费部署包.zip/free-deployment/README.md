# 🆓 iFlytek 多模态面试系统 - 免费部署包

## 📦 包含文件
- `free-deploy.sh` - 一键部署脚本
- `docker-compose-free.yml` - Docker编排配置
- `Dockerfile.backend-free` - 后端容器配置
- `Dockerfile.frontend-free` - 前端容器配置  
- `nginx-free.conf` - Nginx配置
- `.env.example` - 环境变量模板
- `免费云服务器申请指南.md` - 详细申请指南
- `快速部署指南.md` - 快速部署步骤

## 🚀 快速开始

### 1. 申请免费服务器
推荐使用 Oracle Cloud Always Free：https://www.oracle.com/cloud/free/

### 2. 上传文件到服务器
```bash
scp -i your-key.pem -r free-deployment/ ubuntu@your-server-ip:/home/ubuntu/
```

### 3. 连接服务器并部署
```bash
ssh -i your-key.pem ubuntu@your-server-ip
cd free-deployment
chmod +x free-deploy.sh
./free-deploy.sh
```

### 4. 配置API密钥
```bash
cp .env.example .env
nano .env
# 修改 iFlytek API 配置
docker-compose -f docker-compose-free.yml restart
```

### 5. 访问系统
访问: http://your-server-ip

## 📞 技术支持
详细说明请查看 `快速部署指南.md`
